# Differential Expression Detection in scRNA seq Data

`diffexpR` is an R package for detecting differential expression in scRNA Data from two different conditions using the Wasserstein distance and a differential proportion test.

# Installation

# Documentation

# References

