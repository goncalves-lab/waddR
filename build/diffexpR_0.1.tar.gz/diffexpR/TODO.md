# TODO

- [ ] Wasserstein Metric Rcpp implementation differs from wasserstein1d
- [ ] Write Man pages
- [ ] Biological application
- [ ] CI Testing
- [ ] Upload to CRAN / Bioconductor
